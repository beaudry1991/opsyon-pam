package com.realdev.beaudry.payme;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class operat2 extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        return inflater.inflate(R.layout.fragment_op2, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        Button b0 = view.findViewById(R.id.button01);
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dailNumber("101");
            }
        });
        Button b1 = view.findViewById(R.id.button02);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dailNumber("102");
            }
        });
        Button b2 = view.findViewById(R.id.button03);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dailNumber("134");
            }
        });
        Button b3 = view.findViewById(R.id.button04);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dailNumber("134*8");
            }
        });
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setHasOptionsMenu(true);
    }
    private void dailNumber(String code) {
        String ussdCode = "*" + code + Uri.encode("#");
        startActivity(new Intent("android.intent.action.CALL", Uri.parse("tel:" + ussdCode)));
    }
}
